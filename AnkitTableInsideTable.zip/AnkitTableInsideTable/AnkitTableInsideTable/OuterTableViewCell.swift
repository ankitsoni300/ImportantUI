//
//  OuterTableViewCell.swift
//  AnkitTableInsideTable
//
//  Created by Ankit Soni on 09/03/21.
//

import UIKit

class OuterTableViewCell: UITableViewCell {

    @IBOutlet weak var tblViewInner: OwnTableView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        tblViewInner.delegate = self
        tblViewInner.dataSource = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension OuterTableViewCell : UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tblViewInner.dequeueReusableCell(withIdentifier: "InnerTableViewCell", for: indexPath) as? InnerTableViewCell else{
            return UITableViewCell()
        }
        cell.layoutIfNeeded()
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
