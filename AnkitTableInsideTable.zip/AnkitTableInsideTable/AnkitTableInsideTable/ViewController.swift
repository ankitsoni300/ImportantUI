//
//  ViewController.swift
//  AnkitTableInsideTable
//
//  Created by Ankit Soni on 08/03/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tblViewOuter: OwnTableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblViewOuter.delegate = self
        self.tblViewOuter.dataSource = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.main.async {
            self.tblViewOuter.reloadData()
        }
    }
}

extension ViewController : UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tblViewOuter.dequeueReusableCell(withIdentifier: "OuterTableViewCell", for: indexPath) as? OuterTableViewCell else{
            return UITableViewCell()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}

